package com.capgemini.xyz.exception;

public class IllegalFormatException extends Exception{

	public IllegalFormatException() {
		super();
	}

	public IllegalFormatException(String message) {
		super(message);
	}

	
}
