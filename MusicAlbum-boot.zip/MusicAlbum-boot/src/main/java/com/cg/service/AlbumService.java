package com.cg.service;

import com.cg.entity.Album;

public interface AlbumService {
	void saveAlbum(Album album);

	public Album getAlbum(int id);

	public Album updateAlbum(Album album, int id);

	public String deleteAlbum(int id);
	Iterable<Album> getAllAlbums();
	public Album getByName(String name);
	
}
