package com.cg.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Album;
import com.cg.repo.AlbumRepo;

@Repository
@Transactional
public class AlbumServiceImpl implements AlbumService {
	@Autowired
	private AlbumRepo repo;

	@Override

	public void saveAlbum(Album album) {
		repo.save(album);
	}

	@Override

	public Album getAlbum(int id) throws NoSuchElementException {
		try{
			return repo.findById(id).get();
		}catch(NoSuchElementException e) {
			throw new NoSuchElementException("No album is available for this id"+id);
		}
		
	}

	@Override
	public Album updateAlbum(Album album, int id) {
		album.setAlbumId(id);
		repo.save(album);

		return album;
	}

	@Override
	public String deleteAlbum(int id) {
		try{
		Album album = repo.findById(id).get();
		repo.delete(album);
		return "Album deleted";
		}catch(NoSuchElementException e) {
			throw new NoSuchElementException("No album is available for this id"+id);
		}
	}

	@Override
	public Iterable<Album> getAllAlbums() {
		return repo.findAll();
	}

	@Override
	public Album getByName(String name) {
		try{
		return repo.findByAlbumTitle(name);
	}catch(NoSuchElementException e) {
		throw new NoSuchElementException("No album is available for this title"+name);
	}
	}
}
	


