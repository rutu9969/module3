package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Album")
public class Album {
	
	@Id @Column  @GeneratedValue
	private int albumId;
	
	@Column(length=20)
	private String albumTitle;
	
	@Column(length=20)
	private String albumArtist;
	
	@Column(length=20)
	private int albumPrice;

	public int getAlbumId() {
		return albumId;
	}

	public void setAlbumId(int albumId) {
		this.albumId = albumId;
	}

	public String getAlbumTitle() {
		return albumTitle;
	}

	public void setAlbumTitle(String albumTitle) {
		this.albumTitle = albumTitle;
	}

	public String getAlbumArtist() {
		return albumArtist;
	}

	public void setAlbumArtist(String albumArtist) {
		this.albumArtist = albumArtist;
	}

	public int getAlbumPrice() {
		return albumPrice;
	}

	public void setAlbumPrice(int albumPrice) {
		this.albumPrice = albumPrice;
	}

}
