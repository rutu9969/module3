package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.entities.Product;
import com.cg.repo.ProductRepo;

@SpringBootApplication
public class DatabootApplication implements CommandLineRunner{
	@Autowired
	private ProductRepo repo;

	public static void main(String[] args) {
		SpringApplication.run(DatabootApplication.class, args);
	}
	@Override
public void run(String...args) throws Exception {
/*	Product p=new Product();
	p.setName("iphone");
	p.setPrice(1200);
	repo.save(p);
*/
		
		Product p=repo.findById(0).get();
		System.out.println(p.getName()+":"+p.getPrice());
}

}
