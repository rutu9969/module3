

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.entity.Employee;
import com.cg.entity.SBU;

public class TestClass {
	@Test
	public void testGetObject() {
	
	ApplicationContext ctx=new ClassPathXmlApplicationContext("test.xml");
	Employee emp=(Employee)ctx.getBean("employee");
	SBU sbu=(SBU)ctx.getBean("sbu");
	System.out.println("-------SBU details-----------");
	System.out.println(sbu);
	System.out.println("-------Employee details------");
	System.out.println(sbu.getEmpList());

	
	}

}
