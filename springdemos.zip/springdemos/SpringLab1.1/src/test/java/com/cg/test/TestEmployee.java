package com.cg.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.entities.Employee;

public class TestEmployee {
	@Test
	public void testGetObject() {
	
	ApplicationContext ctx=new ClassPathXmlApplicationContext("test.xml");
	Employee emp=(Employee)ctx.getBean("employee");
	System.out.println(emp);

}
}