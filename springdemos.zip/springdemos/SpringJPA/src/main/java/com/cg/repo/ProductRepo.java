package com.cg.repo;

import java.util.List;

import com.cg.entity.Product;

public interface ProductRepo {
	void saveProduct(Product p);
	Product get(int id);
	List<Product> getAll();
	

	
}
