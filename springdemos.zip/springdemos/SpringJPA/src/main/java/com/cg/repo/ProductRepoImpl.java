package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;

@Repository
public class ProductRepoImpl implements ProductRepo {
	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em;

	@Transactional(propagation = Propagation.REQUIRED)
	public void saveProduct(Product p) {
		em.persist(p);

	}

	@Transactional(propagation = Propagation.SUPPORTS)
	public Product get(int id) {
		return em.find(Product.class, id);
	}

	@Transactional
	public List<Product> getAll() {
		return em.createNamedQuery("from Product").getResultList();
	}

}
