package com.cg.ioc;

public class MyLife {
	public MyLife() {
		System.out.println("Initializing");
	}
	public void born() {
		System.out.println("Ready for action");
	}
public void die() {
	System.out.println("System crashed");
}
	
}
