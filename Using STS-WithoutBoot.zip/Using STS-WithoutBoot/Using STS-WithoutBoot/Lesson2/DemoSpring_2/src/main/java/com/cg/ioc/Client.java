package com.cg.ioc;


public class Client{
	
private static Client client;
public static Client getClient()
 {
if(client==null) 
	client=new Client();


return client;
 }
}

