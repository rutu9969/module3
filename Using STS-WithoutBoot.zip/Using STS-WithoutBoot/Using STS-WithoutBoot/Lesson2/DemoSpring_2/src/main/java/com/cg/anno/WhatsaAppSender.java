package com.cg.anno;

import org.springframework.stereotype.Component;

@Component("wap")
public class WhatsaAppSender implements Sender {
	
public WhatsaAppSender() {
	System.out.println("Whatsapp sender is ready");
}
	public void send(String to, String msg) {
		System.out.println("Whatsapp: "+msg+"send to "+to);
	}

}
