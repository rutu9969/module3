package com.cg.test;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMylife {
	@Test
	public void testing() {
		ConfigurableApplicationContext ctx=new ClassPathXmlApplicationContext("annotated.xml");
		
ctx.close();
		
	}

}
